/* Fill these values only when the owner confirms public contact URLs. */
const CONTACT_LINKS = {
  whatsapp: "",  // e.g. https://wa.me/77000000000
  telegram: "",  // e.g. https://t.me/username
  instagram: "", // e.g. https://instagram.com/username
  github: "https://github.com/egorkitsun2"
};
(() => {
  const safeUrl = v => { try { const u = new URL(v); return u.protocol === 'https:' ? u.href : ''; } catch { return ''; } };
  const labels = [
    {key:'whatsapp', label:'WhatsApp', icon:'◉', note:'Перейти в чат', primary:true},
    {key:'telegram', label:'Telegram', icon:'➤', note:'Написать сообщение'},
    {key:'instagram', label:'Instagram', icon:'◎', note:'Перейти в профиль'},
    {key:'github', label:'GitHub', icon:'⌘', note:'Посмотреть профиль разработчика'}
  ];
  const dlg = document.createElement('dialog'); dlg.id='contact-dialog';dlg.className='contact-dialog';dlg.setAttribute('aria-labelledby','contact-dialog-title');
  dlg.innerHTML=`<div class="contact-inner"><div class="contact-top"><span>Давай обсудим твой проект</span><button class="contact-close" type="button" aria-label="Закрыть окно" data-dismiss-contact>×</button></div><h2 id="contact-dialog-title">Где тебе удобнее?</h2><p class="contact-desc">Выбери удобный способ связи.</p><div class="contact-channel-list"></div><p class="contact-help"></p></div>`;
  document.body.append(dlg);
  const list=dlg.querySelector('.contact-channel-list');
  let count=0;
  for(const x of labels){
    const url=safeUrl(CONTACT_LINKS[x.key]);
    const a=document.createElement('a');
    a.className='contact-channel '+(x.primary?'primary ':'')+(url?'is-active':'is-unavailable');
    a.innerHTML=`<span class="chan-icon" aria-hidden="true">${x.icon}</span><span class="channel-text">${x.label}<small>${url?x.note:'Пока не настроено'}</small></span><span class="chan-arrow" aria-hidden="true">${url?'↗':'—'}</span>`;
    if(url){a.href=url;a.target='_blank';a.rel='noopener noreferrer';count++} else {a.setAttribute('aria-disabled','true');a.tabIndex=-1;a.addEventListener('click',e=>e.preventDefault())}
    list.append(a);
  }
  dlg.querySelector('.contact-help').textContent=count<4?'Это демонстрация: прямые ссылки на мессенджеры пока не заполнены. Перед публикацией добавим реальные контакты.':'';
  const closeBtn=dlg.querySelector('[data-dismiss-contact]');
  function openContact(e){if(e){e.preventDefault()} if(!dlg.open){dlg.showModal();document.body.classList.add('modal-open');closeBtn.focus()}}
  document.querySelectorAll('[data-contact]').forEach(a=>a.addEventListener('click',openContact));
  closeBtn.addEventListener('click',()=>dlg.close());
  dlg.addEventListener('close',()=>document.body.classList.remove('modal-open'));
  dlg.addEventListener('click', e=> {if(e.target===dlg) dlg.close()});
  if(new URLSearchParams(window.location.search).has('contact')) openContact();
})();
